package os

func Getenv(string) string

func Exit(int)
